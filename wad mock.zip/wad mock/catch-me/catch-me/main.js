/*

Catch me if you can

*/

var count = 0;

function showCords(event) {

    var x = event.offsetX;
    var y = event.offsetY;

    count++;

    if (count == 80) {
        document.getElementById('counter').style.visibility = 'visible';
        document.getElementById('counter').innerHTML = "Hehehe. You can't catch me !";
    }

    document.getElementById('inner-box').style.top = x + 10 + 'px';
    document.getElementById('inner-box').style.left = y + 10 + 'px';

}