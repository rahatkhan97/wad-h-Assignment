<!doctype html>
<html lang "en">

<head>
<title>SOUND CLOUD  </title>
<meta charset="UTF-8">
<meta name="description" content="UCP Section H Assignment 2">
	<meta name="keywords" content="HTML,CSS,XML,JavaScript,php,sql">
	<meta name="author" content="Rahat">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="https://w.soundcloud.com/icon/?url=http%3A%2F%2Fsoundcloud.com%2Fundefined&color=orange_white&size=32"/>
    <link rel="stylesheet" type="text/css" href="styles.css" />
	<iframe allowtransparency="true" scrolling="no" frameborder="no" 
	src="https://w.soundcloud.com/icon/?url=http%3A%2F%2Fsoundcloud.com%2Fundefined&color=orange_white&size=32" 
	style="width: 32px; height: 32px;"></iframe>
</head>

<body>
<header role="banner" class="header sc-selection-disabled fixed g-dark g-z-index-header show"><div class="header__inner l-container l-fullwidth ">
  <div class="header__left">
    <div class="header__logo left">
      <a href="/" title="Home" class="header__logoLink header__logoLink-iconOnly sc-border-box sc-ir">SoundCloud</a>
      <a href="/" title="Home" class="header__logoLink header__logoLink-wordmark sc-border-box sc-ir">SoundCloud</a>
    </div>
    <nav class="left header__navWrapper" role="navigation">
      <ul class="header__navMenu left sc-list-nostyle">
        <li>
          <a class="header__navMenuItem" data-menu-name="home" href="/discover">Home</a>
        </li>
        <li>
          <a class="header__navMenuItem" data-menu-name="stream" href="/stream">Stream</a>
        </li>
        <li class="header__collection-wrapper">
          <a class="header__navMenuItem" data-menu-name="collection" href="/you/collection">Collection</a>
        </li>
      </ul>
    </nav>
  </div>
  <div class="header__middle">
    <div class="header__search" role="search">
      <form class="headerSearch"><input class="headerSearch__input sc-input g-all-transitions-300" placeholder="Search for artists, bands, tracks, podcasts" type="search" name="q" autocomplete="off" aria-label="Search" aria-autocomplete="list" aria-owns="searchMenuList">
<button class="headerSearch__submit submit sc-ir" type="submit">Search</button>
</form>
    </div>
  </div>
  <div class="header__right sc-clearfix">
      <div class="header__loginMenu left">
        <button type="button" class="g-opacity-transition sc-button sc-button-medium loginButton" tabindex="0" title="Sign in">Sign in</button>
        <button type="button" class="g-opacity-transition sc-button sc-button-medium signupButton sc-button-cta" tabindex="0" title="Create a SoundCloud account">Create account</button>
      </div>
      <div class="header__upload left">
        <a href="/upload" class="uploadButton header__link" tabindex="0"><span class="uploadButton__title">Upload</span><span class="uploadButton__status"></span></a>
      </div>
    <ul class="header__navMenu sc-clearfix sc-list-nostyle left">
      <li><a href="" class="header__moreButton sc-ir" tabindex="0" aria-haspopup="true" role="button" aria-owns="dropdown-button-34">Settings and more</a></li>
    </ul>
  </div>
</div>
</header>


