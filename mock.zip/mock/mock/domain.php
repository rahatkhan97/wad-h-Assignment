<?php

$text = $_POST['url'];
$pattern = "/https?:\/\/(www\.)?([a-zA-Z0-9\.]+)+/";
$matches;

if(!preg_match_all($pattern, $text, $matches))
    echo "Please, enter a valid url!";
else
{   //print_r($matches[0]);
    echo "<br>";
    for($i=0; $i<sizeof($matches[0]); $i++)
	{echo '<a href="'.$matches[0][$i].'">';
      echo" ";
		echo $matches[2][$i]."<br>";
	}
	
}

?>