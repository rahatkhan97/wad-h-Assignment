<!DOCTYPE html>
<html>
    <head>
        <title>Mock Exam</title>

        <link rel="stylesheet" type="text/css" href="css/bootstrap4.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

        <script>
            $(document).ready(function(){
                $('#submit').click(function (event) {
                    event.preventDefault();
                    var url = document.getElementById("url").value;
                    $.ajax({
                       type: "POST",
                       url: "domain.php",
                       data: 'url='+url,
                       success: function(response) {
                           $('#output').html(response);
                       }
                    });
                });
            });
        </script>
    </head>

<body>
    <br><br>
    <div class="container">
        <div class="form-group">
            <form>
                <b><label for="urls">Enter urls here:</label></b>
                <textarea class="form-control" rows="5" id="url" name="url"></textarea><br><br>
                <button type="submit" id="submit">Filter</button>
            </form>
        </div>
        <br><br>
        <div id="output">

        </div>
    </div>

</body>
</html>