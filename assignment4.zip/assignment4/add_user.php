<?php
if(count($_POST)>0) {
	require_once("db.php");
	$sql = "INSERT INTO users (userName, email, password, confirm) VALUES ('" . $_POST["userName"] . "','" . $_POST["email"] . "','" . $_POST["password"] . "','" . $_POST["confirm"] . "')";
	mysqli_query($conn,$sql);
	$current_id = mysqli_insert_id($conn);
	if(!empty($current_id)) {
		$message = "New User Added Successfully";
	}
}
?>
<html>
<head>
<title>Add New User</title>
<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
<div class="message"><?php if(isset($message)) { echo "$message"; } ?></div>
<form name="frmUser" method="post" action="">
<div style="autocomplete">

<table border="0" cellpadding="10" cellspacing="0" width="500" align="center" class="tblSaveForm">

<tr class="tableheader">


<ul>
 
<li><img id="image" src="images/sound.png" width="60" height="50" alt="SoundCloud Logo"/><li>
 <li>
  <a href="http://soundcloud.com/" class="sc-logo" title="Go to SoundCloud.com">SoundCloud</a>
</li>






  <li><a class="active" href="#home">Home</a></li>
  <li><a href="#stream">Stream</a></li>
  <li><a href="#collection">Collection</a></li>


 
  
  <input class="headerSearch__input sc-input g-all-transitions-30" 
  placeholder="Search for artists, bands"
  type="search" name="q" autocomplete="off" aria-label="Search"
  aria-autocomplete="list" aria-owns="searchMenuList">
  
<li><a href="login_user.php">Sign in</a></li>
<li><a href="add_user.php">Create account</a></li>
<li><a href="songs.php">Upload</a></li>
<li><a href="album.php">Album</a></li>
 </ul> 

















<td cospan="2">-----------------------Sign UP------------------------</td>

</tr>
<br>
<tr>

<td><input type="text" name="userName" placeholder="Your name" class="txtField"></td>
</tr>
<tr>

<td><input type="email" name="email"placeholder="Your email" class="txtField"></td>
</tr>

<td><input type="password" name=" password" placeholder="Your password"class="txtField"></td>
</tr>

<td><input type="password" name="confirm" placeholder="Confirm password"class="txtField"></td>
</tr>
<tr>
<td colspan="2"><input type="submit" name="submit" value="Submit" class="btnSubmit"></td>
</tr>
</table>
</div>
</form>
</body></html>