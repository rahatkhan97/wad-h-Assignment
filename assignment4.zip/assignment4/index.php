<?php
require_once("db.php");
$sql = "SELECT * FROM users ORDER BY userId DESC";
$result = mysqli_query($conn,$sql);


if(isset($_POST['submit'])) {

    $userName=$_POST['userName'];
    $password=$_POST['password'];
    $query="select * from users where userName='$userName' and password='$password'";
    $con=mysqli_connect('localhost','root','','users');
    $run=mysqli_query($con,$query);

    if(mysqli_num_rows($run)>0) {
        echo "<script>alert ('user login successfull')</script>";
        $_SESSION['userName']=$userName;
    } else {
        echo"<script>alert('incorrect user name or password')</script>";
    }

}

?>








<html>
<head>
<title>Users List</title>
<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>

<div style="autocomplete">
<form name="frmUser" method="POST" action="">


<table border="0" cellpadding="10" cellspacing="0" width="500" align="center" class="tblSaveForm">

<tr class="tableheader">


<ul>
 
 <li><img id="image" src="images/sound.png" width="60" height="50" alt="SoundCloud Logo"/><li>
 <li>
  <a href="http://soundcloud.com/" class="sc-logo" title="Go to SoundCloud.com">SoundCloud</a>
</li>







  <li><a href="#home">Home</a></li>
  <li><a href="#stream">Stream</a></li>
  <li><a href="#collection">Collection</a></li>


 
  
  <input class="headerSearch__input sc-input g-all-transitions-30" 
  placeholder="Search for artists, bands"
  type="search" name="q" autocomplete="off" aria-label="Search"
  aria-autocomplete="list" aria-owns="searchMenuList">
  
<li><a href="login_user.php">Sign in</a></li>
<li><a href="add_user.php">Create account</a></li>
<li><a href="songs.php">Upload</a></li>
<li><a href="album.php">Album</a></li>
 </ul> 

















<td colspan="2">-----------------------Login------------------------</td>

</tr>
<br>

<tr>

<td><input type="text" name="userName"placeholder="userName" class="txtField"></td>
</tr>

<td><input type="password" name=" password" placeholder="Your password"class="txtField"></td>
</tr>


<tr>
<td colspan="2"><input type="submit" name="submit" value="Submit" class="btnSubmit"></td>

</tr>
</table>
</div>
</form>
</body></html>